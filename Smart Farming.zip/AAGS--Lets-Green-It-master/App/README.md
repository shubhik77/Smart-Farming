# HackOffApp
Made in #HackOff Hackathon.
<br>
Read data from json which was sent by server based on data from json and displays realtime graph.
 
//TODO Add screeshots
