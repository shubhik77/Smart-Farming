package arpit.com.farmis.homerv;

import java.util.ArrayList;

public interface DataLoaded {
    void onDataLoaded(ArrayList<Float> value, String name);
}
