package arpit.com.farmis.network;

import org.json.JSONObject;

import arpit.com.farmis.homerv.Item;

public interface JsonLoaded {
    void onJsonLoaded(JSONObject json);
}
